<?php
    namespace Drupal\register\Form;

    use Drupal\Core\Form\FormBase;
    use Drupal\Core\Form\FormStateInterface;
    use Drupal\Core\Database\Database;
    
    class RegisterForm extends FormBase {
         /**
         * {@inheritdoc}
         */
        public function getFormId() {
            return 'register_form';
        }

        /**
         * {@inheritdoc}
         */
        public function buildForm(array $form, FormStateInterface $form_state) {
            $form['title'] = [
            '#type' => 'textfield',
            '#title' => $this->t('Enter Username'),
            '#required' => TRUE,
            '#attributes' => array(
                'class' => 'form-control col-md-12',
                'id' => 'user_title',
            ),
            ];

            $form['email'] = [
                '#type' => 'email',
                '#title' => $this->t('Enter email address'),
                '#required' => TRUE,
                '#attributes' => array(
                    'class' => 'form-control col-md-6',
                    'id' => 'user_email',
                ),
                ];

            $form['password'] = [
                '#type' => 'password',
                '#title' => $this->t('Enter Your Password'),
                '#required' => TRUE,
                '#attributes' => array(
                    'class' => 'form-control col-md-6',
                    'id' => 'user_password',
                ),
            ];


        //     $result = \Drupal::database()->select('node_field_data', 'n')
        //     ->fields('n', array('id', 'title','type'))
        //     ->condition('n.type', 'course')
        //     ->execute()->fetchAllAssoc('id');
       
        //     $rows = array();
        //     foreach ($result as $row => $content) {
        
        //         $rows[] = array(
        //             'data' => array($content->title
        //                     ));
        //                     $courses = array($rows => $rows);
        //    }

            
            

            $value1 = array('User' => t('User'),
            'Trainer' => t('Trainer'));
            

            $form['role'] = [
            '#type' => 'select',
            '#title' => $this->t('Role'),
            '#required' => TRUE,
            '#attributes' => array(
                'class' => 'form-control col-md-6',
                'id' => 'user_role',
            ),
            '#options' => $value1
            ];

            $query = \Drupal::database()->query("SELECT nid, title FROM {node_field_data}");
            echo $query;
            die();
            $query = \Drupal::database()->select('node_field_data', 'nfd');
            $query->addField('nfd', 'nid');
            $query->condition('nfd.type', 'course');
            $query->condition('nfd.status', 1);
            $results = $query->execute();
            
            $form['course'] = [
                '#type' => 'select',
                '#title' => $this->t('Course'),
                '#required' => TRUE,
                '#attributes' => array(
                    'class' => 'form-control col-md-6',
                    'id' => 'user_course',
                ),
                '#options' => $results
            ];

           

            

            $form['actions']['#type'] = 'actions';



            $form['actions']['submit'] = [
            '#type' => 'submit',
            '#value' => $this->t('Save'),
            '#button_type' => 'primary',
        
            ];
            return $form;
        }


       
        /**
         * {@inheritdoc}
         */
        public function submitForm(array &$form, FormStateInterface $form_state) {

            $title = $form_state->getValue('title');
            $description = $form_state->getValue('description');
            $email = $form_state->getValue('email');
            $city = $form_state->getValue('city');
            $zipcode = $form_state->getValue('zipcode');

            //Insert form value in table
            $query=\Drupal::database();
            $query->insert('enquiry_form') -> fields(array(
                'title'=>$title,
                'description'=>$description,
                'email'=>$email,
                'city'=>$city,
                'zipcode'=>$zipcode

            ))->execute();


            //Give status of form data value
            \Drupal::messenger()->addMessage('Data Saved ');
            $this->messenger()->addStatus($this->t('Book Title  is @title', ['@title' => $form_state->getValue('title')]));
            $this->messenger()->addStatus($this->t('Book Description  is @description', ['@description' => $form_state->getValue('description')]));
            $this->messenger()->addStatus($this->t('Your email address  is @email', ['@email' => $form_state->getValue('email')]));
            $this->messenger()->addStatus($this->t('Your City  is @city', ['@city' => $form_state->getValue('city')]));
            $this->messenger()->addStatus($this->t('Your Zipcode  is @zipcode', ['@zipcode' => $form_state->getValue('zipcode')]));
        }
    }
?>