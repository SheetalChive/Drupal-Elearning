$(document).ready(function(){
    $("nav ul").addClass('navbar-nav');
    $("nav").adclass('navbar');
    $("nav").adclass('navbar-expand-lg');
    $("nav").adclass('navbar-dark');
    $("nav").adclass('ftco-navbar-light');
    $("nav").adclass('bg-dark');
});;
