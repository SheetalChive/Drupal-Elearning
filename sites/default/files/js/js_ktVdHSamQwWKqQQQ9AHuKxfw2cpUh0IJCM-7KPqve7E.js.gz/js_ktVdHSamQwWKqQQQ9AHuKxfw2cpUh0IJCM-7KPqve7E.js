$(document).ready(function(){
    $("nav ul").addClass('navbar-nav');
    $("nav").adclass('navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light');
});;
