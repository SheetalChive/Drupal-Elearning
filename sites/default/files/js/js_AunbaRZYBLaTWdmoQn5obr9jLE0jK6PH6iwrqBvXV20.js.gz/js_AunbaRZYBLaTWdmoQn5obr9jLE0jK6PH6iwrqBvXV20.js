$(document).ready(function(){
   
    $("nav").adclass('navbar');
    $("nav").adclass('navbar-expand-lg');
    $("nav").adclass('navbar-dark');
    $("nav").adclass('ftco-navbar-light');
    $("nav").adclass('bg-dark');
    $("nav ul").addClass('navbar-nav');
    $("nav ul").addClass('mr-auto');
});;
