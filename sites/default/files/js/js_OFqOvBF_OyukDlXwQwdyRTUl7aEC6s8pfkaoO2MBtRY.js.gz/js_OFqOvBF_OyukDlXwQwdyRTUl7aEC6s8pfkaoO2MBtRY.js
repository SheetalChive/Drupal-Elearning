$(document).ready(function(){
    $("nav ul").addClass('navbar-nav');
});;
